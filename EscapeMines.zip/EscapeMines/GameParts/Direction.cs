﻿using System;

namespace EscapeMines.GameParts
{
	public enum Direction
	{
		NorthDirection = 'N',
		SouthDirection = 'S',
		WestDirection = 'W',
		EastDirection = 'E'
	}

}
