﻿namespace EscapeMines.Services
{
    public interface IFileDialogOpener
    {
        string GetFilePathFromDialog();
    }
}